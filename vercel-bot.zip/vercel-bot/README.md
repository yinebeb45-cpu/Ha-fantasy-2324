# Ha Fantasy Bot (Vercel webhook)

## Deploy
1. Put these files in GitHub repo
2. Import on Vercel
3. Add env vars
4. Deploy
5. Set webhook (see below)

## Env vars
BOT_TOKEN
ADMIN_CHAT_ID=-1004468798532
SUPABASE_URL
SUPABASE_SERVICE_KEY

## After deploy
Open this URL once (replace TOKEN and YOUR_VERCEL_URL):

https://api.telegram.org/bot<BOT_TOKEN>/setWebhook?url=https://YOUR_VERCEL_URL/api/telegram
